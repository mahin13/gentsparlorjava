import java.lang.*;
import Frames.*;

public class Start
{
	public static void main(String args[])
	{
		GentsParlor gp = new GentsParlor();
		gp.setVisible(true);
	}
}